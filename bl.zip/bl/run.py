#_*_coding:utf-8_*_
#作者       ：  Deth
#创建时间    : 2020/5/13 10:46
#文件       ： run. py
# IDE       : PyCharm
from scrapy import cmdline

cmdline.execute(['scrapy','crawl','bi'])